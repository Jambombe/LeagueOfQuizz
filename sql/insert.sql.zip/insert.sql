﻿insert into questions_simples(ennonce, image) values ("Quel est le nom de ce champion ?", "jhin.jpg");
insert into reponses_questions_simples values (1, "Fizz", 0);
insert into reponses_questions_simples values (1, "Jhin", 1);
insert into reponses_questions_simples values (1, "Jayce", 0);
insert into reponses_questions_simples values (1, "Draven", 0);

insert into questions_simples(ennonce, image) values ("Comment s\'appelle cet objet ?", "rabadon.png");
insert into reponses_questions_simples values (2, "Anneau de Doran", 0);
insert into reponses_questions_simples values (2, "Soif de sang", 0);
insert into reponses_questions_simples values (2, "Coiffe de Rabadon", 1);
insert into reponses_questions_simples values (2, "Echo de Ludden", 0);

insert into questions_simples(ennonce, image) values ("Classez ces 3 rangs du meilleur au moins bon", "diamond.png");
insert into reponses_questions_simples values (3, "Platine > Argent > Or", 0);
insert into reponses_questions_simples values (3, "Or > Platine > Argent", 0);
insert into reponses_questions_simples values (3, "Argent > Platine > Or", 0);
insert into reponses_questions_simples values (3, "Platine > Or > Argent", 1);

insert into questions_simples(ennonce, image) values ("Combien coûte une potion de soin", "health_potion.png");
insert into reponses_questions_simples values (4, "25", 0);
insert into reponses_questions_simples values (4, "35", 0);
insert into reponses_questions_simples values (4, "50", 1);
insert into reponses_questions_simples values (4, "75", 0);

insert into questions_simples(ennonce, image) values ("Quel est ce sort d\'invocateur ?", "emb.png");
insert into reponses_questions_simples values (5, "Embrasement", 1);
insert into reponses_questions_simples values (5, "Saut éclair", 0);
insert into reponses_questions_simples values (5, "Fantôme", 0);
insert into reponses_questions_simples values (5, "Soins", 0);

insert into questions_simples(ennonce, image) values ("Quel est le niveau maximum d\'honneur ?", "honor.png");
insert into reponses_questions_simples values (6, "4", 0);
insert into reponses_questions_simples values (6, "5", 1);
insert into reponses_questions_simples values (6, "6", 0);
insert into reponses_questions_simples values (6, "7", 0);

insert into questions_simples(ennonce, image) values ("Quel est le plus haut de niveau de matrîse d\'un champion ?", "mastery.png");
insert into reponses_questions_simples values (7, "5", 0);
insert into reponses_questions_simples values (7, "6", 0);
insert into reponses_questions_simples values (7, "7", 1);
insert into reponses_questions_simples values (7, "8", 0);

insert into questions_simples(ennonce, image) values ("Combien de joueurs s\'opposent sur la Forêt Torturée ?", "forest.jpg");
insert into reponses_questions_simples values (8, "3", 1);
insert into reponses_questions_simples values (8, "4", 0);
insert into reponses_questions_simples values (8, "5", 0);
insert into reponses_questions_simples values (8, "6", 0);

insert into questions_simples(ennonce, image) values ("La partie de termine ...", "victory.png");
insert into reponses_questions_simples values (9, "Après une heure de jeu", 0);
insert into reponses_questions_simples values (9, "En tuant le baron Nashor", 0);
insert into reponses_questions_simples values (9, "En détruisant les trois inhibiteurs", 0);
insert into reponses_questions_simples values (9, "En détruisant le Nexus adverse", 1);

insert into questions_simples(ennonce, image) values ("Combien y a-t-il d\'emplacements d\'objets (hors relique) ?", "cull.png");
insert into reponses_questions_simples values (10, "4", 0);
insert into reponses_questions_simples values (10, "5", 0);
insert into reponses_questions_simples values (10, "6", 1);
insert into reponses_questions_simples values (10, "7", 0);
